'use strict';

angular.module('myApp', ['ngRoute', 'leaflet-directive'])

.factory('Estacoes', ['$http', '$log', '$q', function($http, $log, $q) {
	$log.error('entrei factory Estações............................');
    var d = $q.defer();
    var promise = acessaEstacoes($http, $log, $q);
    promise.then(function(resultado) {
        d.resolve(resultado);
    });
    return d.promise;
}])

.factory('Previsoes', ['$http', '$log', '$q', function($http, $log, $q) {
	$log.error('entrei factory Previsões............................');
    var d = $q.defer();
    var promise = acessaPrevisoes($http, $log, $q);
    promise.then(function(resultado) {
        d.resolve(resultado);
    });
    return d.promise;
}])

.controller('MainCtrl', ["$scope", "$log", "Estacoes", function($scope, $log, Estacoes) {
	$log.error('entrei Main controller............................');
    var promiseEstacoes = Estacoes;
    promiseEstacoes.then(function(resultado) {
        $scope.estacoes = Estacoes.estacoes;
        $scope.estacaoSelecionada = Estacoes.estacaoSelecionada;
        $scope.markers = Estacoes.markers;
    });
}])

.controller('PredictionCtrl', ["$http", "$scope", "$log", 'Estacoes', 'Previsoes', function($http, $scope, $log, Estacoes, Previsoes) {
	$log.error('entrei Prediction controller............................');
    var promiseEstacoes = Estacoes;
    promiseEstacoes.then(function(resultado) {
        $scope.estacoes = resultado.estacoes;
        $scope.estacaoSelecionada = resultado.estacaoSelecionada;
        $scope.markers = resultado.markers;
    });
    var promisePrevisoes = Previsoes;
    promisePrevisoes.then(function(resultado) {
        $scope.previsoes = resultado.previsoes;
    });
	angular.extend($scope, {
		poaCenter: {
			lat: -30.035,
			lng: -51.17,
			zoom: 12
		}
	});
}])

.config(['$routeProvider', function($routeProvider) {
	$routeProvider
		.when('/view1', {
			templateUrl: 'view1.html',
			controller: 'MainCtrl'
		})
		.when('/view2', {
			templateUrl: 'view2.html',
			controller: 'MainCtrl'
		})
		.when('/view3', {
			templateUrl: 'view3.html',
			controller: 'MainCtrl'
		})
		.when('/view4', {
			templateUrl: 'view4.html',
			controller: 'PredictionCtrl'
		})
		.when('/view5', {
			templateUrl: 'view5.html',
			controller: 'PredictionCtrl'
		})
		.otherwise({
			redirectTo: '/view1'
		});
}])

function acessaEstacoes($http, $log, $q) {
	$log.error('entrei acessaEstacoes............................');
    var d = $q.defer();
	var url = 'https://metroclimaestacoes.procempa.com.br/metroclima/seam/resource/rest/externalRest/leituraAtual';
    var saida = { estacoes: [], estacaoSelecionada: null, markers: null }
	$http.get(url)
    .success(function(estacoes){
        angular.forEach(estacoes, function(estacao) {
            if (estacao.previsaoEstacaoWS) {
                if (saida.estacaoSelecionada == null) {
                    saida.estacaoSelecionada = estacao.estacao;
                }
                saida.estacoes.push(estacao);
            }
        });
        saida.markers = getMapMarkers(saida.estacoes, $log);
        d.resolve(saida);
    })
    .error(function(data, error){ 
        $log.error( "NADA FEITO!!! (" + url + ") " + error); 
    });
    return d.promise;
};

function getMapMarkers(estacoes, $log) {
	$log.error('entrei getMapMarkers............................');
	var markers = [];
	angular.forEach(estacoes, function(estacao) {
		markers.push(
			{ lat: estacao.latitude, 
			  lng: estacao.longitude, 
			   message: "<p>" + estacao.estacao + "</p>"
			 + "<p><img class='mapa_icone_tempo' src='images/ico_" + estacao.previsaoEstacaoWS.iconePrevisao + ".png' title='" + estacao.previsaoEstacaoWS.iconePrevisao + "'></p>"
			 + "<p class='min_max2'>" + estacao.temperaturaExterna + " ºC</p>"
			 + "<p>Umidade: " + estacao.umidadeExterna + " %</p>"
			 + "<p>Pressão: " + estacao.pressao + " hPa</p>"
			 + "<p>Vento: " + estacao.velocidadeVento + " Km/h&nbsp;&nbsp;&nbsp;<img src='images/vento_" + estacao.quadranteVento + ".png' title='" + estacao.quadranteVento + "'></p>"
			}
		);
	});
    return markers;
}

function acessaPrevisoes($http, $log, $q) {
	$log.error('entrei acessaPrevisoes............................');
    var d = $q.defer();
	var urlPrevisoes = 'https://metroclimaestacoes.procempa.com.br/metroclima/seam/resource/rest/externalRest/previsaoFutura';
	var saida = { previsoes: [] };
	
	$http.get(urlPrevisoes)
    .success(function(data){
        saida.previsoes = data;
        d.resolve(saida);
    })
    .error(function(data, error){ 
        $log.error( "NADA FEITO!!! (" + url + ") " + error); 
    });
    return d.promise;
}
